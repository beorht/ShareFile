


import json
from datetime import datetime

#1
def read_txt(prompt):
    while True:
        text = input(prompt).strip()

        if text:
            return text

#2
def read_amount(prompt):
    while True:
        value = input(prompt).strip()

        try:
            amount = float(value)
        except ValueError:
            print("Xato: son kiriting")
            continue

        if amount <= 0:
            print("Xato: summa musbat bo'lishi kerak")
            continue

        return amount

#3
def read_int(prompt):
    while True:
        value = input(prompt).strip()

        try:
            return int(value)
        except ValueError:
            print("Xato: butun son kiriting")
#4
def add_expense(expenses, title, category, amount):

    if expenses:
        yangi_id = max(
            expense["id"] for expense in expenses
        ) + 1
    else:
        yangi_id = 1

    expense = {
        "id": yangi_id,
        "title": title.strip(),
        "category": category.strip().lower(),
        "amount": round(float(amount), 2),
        "date": datetime.now().strftime("%d.%m.%Y")
    }

    expenses.append(expense)

    return expense
                     